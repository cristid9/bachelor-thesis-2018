import json
import socket
from src.model_predef import PORT
from src.model_predef import IP
from src.model_predef import BUFFER_SIZE

from src.data_processor import DataProcessor

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((IP, PORT))
s.listen(1)
data_processor = DataProcessor()


conn, addr = s.accept()
print('Starting server on address:', addr)
while 1:
    data = conn.recv(BUFFER_SIZE)
    print("received data:", data)

    data_main = data.decode()

    while data != b'' and data.decode()[-1] != '\n':
        data = conn.recv(BUFFER_SIZE)
        data_main += data.decode()

    if not data:
        break

    data_main_json = json.loads(data_main)
    print(data_main_json)
    conn.send(data_processor.dispatch_request(data_main_json['modelType'], data_main_json['numberOfWires']))

conn.close()
