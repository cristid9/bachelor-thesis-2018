import threading
from asyncio import Queue, sleep

import numpy
import sys

from src.model_predef import TRAINED_MODELS_LOCATION
from six.moves import cPickle
import theano

# sys.setdefaultencoding('utf8')

class ModelThreadPool:

    def __init__(self):
        self.bs_in_queue = Queue()
        self.bs_out_queue = Queue()

        thread = threading.Thread(target=self.bubble_sorter, args=())
        thread.daemon = True
        thread.start()

        thread2 = threading.Thread(target=self.insert_sorter(), args=())
        thread2.daemon = True
        thread2.start()


        # Repeat the process for the rest of **future** the threads


    def get_num_swaps(self, num_wires):
        num_swaps = 0
        for i in range(0, num_wires):
            num_swaps += i
        return 2 * num_swaps

    def input_converter(self, num):
        return numpy.array(
            [[[float(i) for i in "{0:>09b}".format(num)]
              * self.get_num_swaps(num)]])


    def bubble_sorter(self):
        f = open(TRAINED_MODELS_LOCATION["bubble_sorter"], 'rb')
        fn = cPickle.load(f, encoding='latin1')

        while True:
            if self.bs_in_queue.empty(): continue
            num_wires = self.bs_in_queue.get()
            self.bs_out_queue.put(fn(self.input_converter(num_wires)))


    def query_bubble_sorter(self, num_wires):
        self.bs_in_queue.put(num_wires)
        sleep(2)
        return self.bs_out_queue.get()

    def insert_sorter(self):
        f = open(TRAINED_MODELS_LOCATION["insertion_sorter"], 'rb')
        fn = cPickle.load(f, encoding='latin1')

        while True:
            if self.bs_in_queue.empty(): continue
            num_wires = self.bs_in_queue.get()
            self.bs_out_queue.put(fn(self.input_converter(num_wires)))


    def query_insert_sorter(self, num_wires):
        self.bs_in_queue.put(num_wires)
        sleep(2)
        return self.bs_out_queue.get()