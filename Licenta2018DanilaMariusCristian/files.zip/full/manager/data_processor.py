import json

from src.model_thread_pool import ModelThreadPool
from src.model_predef import MODEL_TYPES

class DataProcessor:
    def __init__(self):
        self.pool = ModelThreadPool()
        self.treshhold = 0.5


    def get_num_swaps(self, num_wires):
        num_swaps = 0
        for i in range(0, num_wires):
            num_swaps += i
        return 2 * num_swaps


    def dispatch_request(self, model_type, num_wires):
        if model_type not in MODEL_TYPES:
            print("[WARNING] Attempt to run unrecognized model")
        swaps = self.pool.bubble_sorter(model_type, num_wires).to_list()
        converted_swaps = self.approximate_nets_inputs(swaps)

        master_swaps = []
        # group tuples of 2
        save = None
        for v in converted_swaps:
            if save != None:
                master_swaps.append((save, v))
                save = None
            else:
                save = v

        return json.dumps(master_swaps)


    def approximate_nets_inputs(self, values):
        master_val = []
        for prob_seq in values:
            apps_value = []
            for v in prob_seq:
                if v >= self.treshhold:
                    apps_value.append(1)
                else:
                    apps_value.append(0)
            master_val.append(int(apps_value.join(""), 2))
        return master_val