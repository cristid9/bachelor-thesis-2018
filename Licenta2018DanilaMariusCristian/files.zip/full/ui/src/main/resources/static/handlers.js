/**
 * jQuery handlers for UI-controls present in the page
 */

/*
$("#generate")  .on('click', function(e) {
    console.log("Click on generate detected...");
}); 

$("#chose_another_model").on('click', function(e) {
    console.log("Another model is going to be chosen...");
}); 


$("#reset_num_wires").on('click', function(e) {
    console.log("Reset number of wires...");
}); 
*/


