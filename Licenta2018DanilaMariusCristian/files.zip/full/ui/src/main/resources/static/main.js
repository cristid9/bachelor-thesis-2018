console.log("Initializing the core graphics...");


var main = function () {

    var container = document.getElementById("network_output");
    var paper = Raphael(container, 600, 800);
    var chosen_model = null;

    $("#bubble_sorter").on('click', function() {
        chosen_model = 'bubble_sorter';
        console.log("foo bar bubble");
    });

    $("#insertion_sorter").on('click', function() {
        chosen_model = 'insertion_sorter';
        console.log("foo bar insert");
    });



    var draw_network = function(num_wires, comparators) {
        console.log("Core SN drawer called...");
        var wire_y_offset = 5*3;
        var network_x_offset = 10;

        for (var i = 0; i < num_wires; ++i) {
            var line = paper.path( ["M", "10", 10 + i * 10, "L",
                wire_y_offset * Math.pow(num_wires, 2), 10 + i * 10]);
        }

        for (var j = 0; j < comparators.length; ++j) {
            var line = paper.path( ["M", network_x_offset * 5, comparators[j][0] * 10 + 10, "L",
                network_x_offset * 5, comparators[j][1] * 10 + 10] );

            network_x_offset++;
        }

    };


    $("#genearte_preview").on('click', function () {
        $.post( "/generate_sorting_net",
            {
                modelType: chosen_model ,
                numberOfWires: parseInt($("#network-size").val())
            })
            .done(function( data ) {
                console.log( "Data Loaded: " + data );

                $("#load").show();
                setTimeout(function() {
                    $("#load").hide();
                    draw_network(parseInt($("#network-size").val()), [JSON.parse(data));
                }, 3000);
            });


    });

    // test

};

