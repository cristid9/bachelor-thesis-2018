package com.sorting_network_web_ui.demo;

public enum ModelType {
    BUBBLE_SORTER("BUBBLE_SORTER"),
    INSERTION_SORTER("INSERTION_SORTER");

    private final String name;

    ModelType(String s) {
        name = s;
    }
}
