package com.sorting_network_web_ui.demo;

import json_models.ModelManagerRequest;
import json_models.ModelManagerResponse;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;

@Controller
public class MainController {

    @RequestMapping("/")
    @ResponseBody
    public ModelAndView index() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("main.html");
        return modelAndView;
    }


    @ResponseBody
    @RequestMapping(value = "/generate_sorting_net", method = RequestMethod.POST)
    public String generateNetworkResult(@RequestParam String modelType, @RequestParam int numberOfWires) {
        ObjectMapper objectMapper = new ObjectMapper();
        System.out.println(modelType);
        System.out.println(numberOfWires);


        ModelType modelType1 = null;
        if (modelType.equals(ModelType.BUBBLE_SORTER.name().toLowerCase())) {
            modelType1 = ModelType.BUBBLE_SORTER;
        } else {
            modelType1 = ModelType.INSERTION_SORTER;
        }

        ModelManagerResponse response = new ManagerClient().queryModelManager(modelType1, numberOfWires);

        return "kjk";
    }
}